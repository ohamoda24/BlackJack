import java.util.ArrayList;

public class Dealer {

public int handValue;
public boolean shouldHit; //if 16 or above, must stand according to rules
public boolean houseWins;
public ArrayList<Cards> hand = new ArrayList<>();
public int score;
public boolean isBust;


    public Dealer(){


    }
}
