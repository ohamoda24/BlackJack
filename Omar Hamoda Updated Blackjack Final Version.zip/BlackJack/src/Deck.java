public class Deck {



    public Deck(String pSuit, int pValue){



    }

    public void deal(){

    }

    public void giveCard(){

    }

}
